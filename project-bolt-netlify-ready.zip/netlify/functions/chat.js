import { config } from 'dotenv';
import OpenAI from 'openai';

config(); // Load .env variables

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default async (req, context) => {
  if (!process.env.OPENAI_API_KEY) {
    return new Response(JSON.stringify({
      error: 'OpenAI API key is not configured. Please check server configuration.'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  try {
    const { message } = await req.json();

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are a helpful AI assistant specializing in donor management and fundraising strategy. Provide concise, practical advice based on donor data and fundraising best practices.'
        },
        { role: 'user', content: message }
      ],
    });

    return new Response(JSON.stringify(completion), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error("OpenAI API Error:", error);
    const errorMessage = error?.response?.data?.error?.message || error.message || 'Unknown error';

    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};