import { Handler } from '@netlify/functions';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json'
};

export const handler: Handler = async (event) => {
  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: corsHeaders,
      body: ''
    };
  }

  // Validate request method
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  // Validate API key
  if (!process.env.OPENAI_API_KEY) {
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'OpenAI API key is not configured' })
    };
  }

  try {
    // Parse and validate request body
    if (!event.body) {
      throw new Error('Request body is required');
    }

    const { message } = JSON.parse(event.body);

    if (!message) {
      throw new Error('Message is required');
    }

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a helpful AI assistant specializing in donor management and fundraising strategy. Provide concise, practical advice based on donor data and fundraising best practices.'
        },
        { role: 'user', content: message }
      ],
      model: 'gpt-3.5-turbo',
      temperature: 0.7,
      max_tokens: 500
    });

    // Validate OpenAI response
    if (!completion.choices[0]?.message?.content) {
      throw new Error('Invalid response from OpenAI API');
    }

    // Return successful response
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: completion.choices[0].message.content
      })
    };
  } catch (error) {
    console.error('Chat function error:', error);
    
    // Return appropriate error response
    return {
      statusCode: error instanceof Error && error.message.includes('Request body') ? 400 : 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        error: error instanceof Error ? error.message : 'An unexpected error occurred'
      })
    };
  }
};