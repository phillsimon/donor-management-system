export default async (req, context) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
      }
    });
  }

  const key = process.env.OPENAI_API_KEY;

  // Log environment variable status
  console.log('Environment check:', {
    keyExists: !!key,
    envVarsAvailable: Object.keys(process.env).length
  });

  return new Response(
    JSON.stringify({
      OPENAI_API_KEY_EXISTS: !!key,
      PARTIAL_KEY: key ? `${key.slice(0, 5)}...${key.slice(-5)}` : null,
      ENV_VARS_AVAILABLE: Object.keys(process.env).length
    }),
    {
      status: 200,
      headers: { 
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Cache-Control': 'no-store'
      }
    }
  );
};