/*
  # Assign admin role to all existing users
  
  1. Changes
    - Assign admin role to all authenticated users
    - Ensure no duplicate assignments
  
  2. Security
    - Maintains existing RLS policies
*/

-- Get admin role ID and assign to all users
INSERT INTO user_roles (user_id, role_id)
SELECT 
  users.id,
  roles.id
FROM auth.users as users
CROSS JOIN roles
WHERE 
  roles.name = 'admin'
  AND NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_roles.user_id = users.id
    AND user_roles.role_id = roles.id
  );

-- Log the assignments
DO $$
DECLARE
  assignment_count integer;
BEGIN
  SELECT COUNT(*) INTO assignment_count
  FROM user_roles ur
  JOIN roles r ON r.id = ur.role_id
  WHERE r.name = 'admin';

  RAISE NOTICE 'Admin role assignments completed. % users now have admin role', assignment_count;
END $$;