/*
  # Rename gift matches column in donors table
  
  1. Changes
    - Rename num_of_gift_matches column to "# Of Gift Matches"
    - Update index to use new column name
    - Preserve data during migration
  
  2. Security
    - Maintains existing RLS policies
    - Preserves data integrity during column rename
*/

-- Rename the column while preserving data
DO $$ 
BEGIN
  -- First check if the old column exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'donors' AND column_name = 'num_of_gift_matches'
  ) THEN
    -- Drop the old index first
    DROP INDEX IF EXISTS donors_num_gift_matches_idx;
    
    -- Rename the column
    ALTER TABLE donors RENAME COLUMN num_of_gift_matches TO "# Of Gift Matches";
    
    -- Create new index with updated column name
    CREATE INDEX donors_gift_matches_idx ON donors("# Of Gift Matches");
  END IF;
END $$;