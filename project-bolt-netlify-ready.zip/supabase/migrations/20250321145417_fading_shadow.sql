/*
  # Update workflow responses table for collaboration

  1. Changes
    - Add public read access to workflow responses
    - Update RLS policies to allow all authenticated users to read responses
    - Keep write access restricted to response owner

  2. Security
    - Enable RLS
    - Allow authenticated users to read all responses
    - Restrict write access to response owner
*/

-- Update RLS policies for workflow_responses
DROP POLICY IF EXISTS "Users can read their own responses" ON workflow_responses;

-- Allow all authenticated users to read responses
CREATE POLICY "Users can read all responses"
  ON workflow_responses
  FOR SELECT
  TO authenticated
  USING (true);

-- Add user profiles view for response attribution
CREATE VIEW user_profiles AS
SELECT 
  id,
  email,
  raw_user_meta_data->>'full_name' as full_name
FROM auth.users;

-- Grant access to the view
GRANT SELECT ON user_profiles TO authenticated;