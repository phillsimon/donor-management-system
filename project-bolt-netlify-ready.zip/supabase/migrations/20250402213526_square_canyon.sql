/*
  # Update messages table and policies

  1. Changes
    - Safely check if table exists before creating
    - Add missing policies if needed
    - Ensure proper constraints and indexes

  2. Security
    - Enable RLS
    - Update policies for proper access control
*/

-- Safely create messages table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'messages') THEN
    CREATE TABLE messages (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id uuid NOT NULL REFERENCES auth.users(id),
      role text NOT NULL,
      content text NOT NULL,
      created_at timestamptz DEFAULT now(),
      CONSTRAINT messages_role_check CHECK (role IN ('user', 'assistant'))
    );
  END IF;
END $$;

-- Enable RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can insert messages" ON messages;
    DROP POLICY IF EXISTS "Users can read own messages" ON messages;
    DROP POLICY IF EXISTS "Enable update access for own messages" ON messages;
    DROP POLICY IF EXISTS "Enable delete access for own messages" ON messages;
EXCEPTION
    WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
CREATE POLICY "Users can insert messages"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own messages"
  ON messages
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Enable update access for own messages"
  ON messages
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable delete access for own messages"
  ON messages
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'messages_pkey') THEN
        CREATE INDEX messages_pkey ON messages(id);
    END IF;
END $$;