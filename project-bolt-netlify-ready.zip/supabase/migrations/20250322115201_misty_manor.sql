/*
  # Add version control for donor analysis

  1. New Tables
    - `analysis_versions`
      - `id` (uuid, primary key)
      - `donor_id` (text, required)
      - `user_id` (uuid, required)
      - `version` (integer, required)
      - `note` (text)
      - `created_at` (timestamptz)
      - `is_current` (boolean)

  2. Security
    - Enable RLS on analysis_versions table
    - Add policies for authenticated users to:
      - Insert their own versions
      - Read their own versions
      - Update their own versions
*/

-- Create analysis_versions table
CREATE TABLE analysis_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donor_id text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  version integer NOT NULL,
  note text,
  created_at timestamptz DEFAULT now(),
  is_current boolean DEFAULT false,
  UNIQUE (donor_id, user_id, version)
);

-- Enable RLS
ALTER TABLE analysis_versions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can insert their own versions"
  ON analysis_versions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read their own versions"
  ON analysis_versions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own versions"
  ON analysis_versions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Add indexes
CREATE INDEX analysis_versions_donor_user_idx ON analysis_versions(donor_id, user_id);
CREATE INDEX analysis_versions_current_idx ON analysis_versions(is_current);

-- Add foreign key to workflow_responses
ALTER TABLE workflow_responses 
ADD COLUMN version_id uuid REFERENCES analysis_versions(id);

-- Add index for version lookups
CREATE INDEX workflow_responses_version_idx ON workflow_responses(version_id);