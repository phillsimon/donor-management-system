/*
  # Assign admin roles to specific users
  
  1. Changes
    - Assign admin role to users with IDs:
      - 383a7a78-555b-47fa-ac3e-94ff5a9ccac0
      - fb33a856-8948-480f-a4fe-3ed86103a09b
    - Ensure idempotency by checking if roles are already assigned
  
  2. Security
    - Only affects specified users
    - Maintains existing RLS policies
*/

-- Assign admin role to specific users
INSERT INTO user_roles (user_id, role_id)
SELECT 
  users.id,
  roles.id
FROM auth.users as users
CROSS JOIN roles
WHERE 
  roles.name = 'admin'
  AND users.id IN (
    '383a7a78-555b-47fa-ac3e-94ff5a9ccac0',
    'fb33a856-8948-480f-a4fe-3ed86103a09b'
  )
  AND NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_roles.user_id = users.id
    AND user_roles.role_id = roles.id
  );

-- Log the assignments for verification
DO $$
DECLARE
  assigned_count integer;
BEGIN
  SELECT COUNT(*) INTO assigned_count
  FROM user_roles ur
  JOIN roles r ON r.id = ur.role_id
  WHERE r.name = 'admin'
  AND ur.user_id IN (
    '383a7a78-555b-47fa-ac3e-94ff5a9ccac0',
    'fb33a856-8948-480f-a4fe-3ed86103a09b'
  );

  RAISE NOTICE 'Admin role assignments completed. % users now have admin role.', assigned_count;
END $$;