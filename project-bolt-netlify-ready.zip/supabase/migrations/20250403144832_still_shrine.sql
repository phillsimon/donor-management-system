-- Drop existing policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can insert own donors" ON donors;
    DROP POLICY IF EXISTS "Users can read own donors" ON donors;
    DROP POLICY IF EXISTS "Users can update own donors" ON donors;
    DROP POLICY IF EXISTS "Users can delete own donors" ON donors;
EXCEPTION
    WHEN undefined_object THEN NULL;
END $$;

-- Disable RLS temporarily for testing
ALTER TABLE donors DISABLE ROW LEVEL SECURITY;

-- Make user_id nullable to allow public access during development
ALTER TABLE donors ALTER COLUMN user_id DROP NOT NULL;

-- Add index for better performance
CREATE INDEX IF NOT EXISTS donors_user_id_created_at_idx ON donors(user_id, created_at DESC);