/*
  # Simplify RLS policies for testing
  
  1. Changes
    - Drop existing policies
    - Create simple policies that allow all authenticated users to:
      - Read all donors
      - Insert donors
      - Update donors
      - Delete donors
  
  2. Security
    - Maintain RLS enabled but with simplified access
*/

-- Drop existing policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can read all donors" ON donors;
    DROP POLICY IF EXISTS "Users can insert own donors" ON donors;
    DROP POLICY IF EXISTS "Users can update own donors" ON donors;
    DROP POLICY IF EXISTS "Users can delete own donors" ON donors;
EXCEPTION
    WHEN undefined_object THEN NULL;
END $$;

-- Enable RLS
ALTER TABLE donors ENABLE ROW LEVEL SECURITY;

-- Create simplified policies
CREATE POLICY "Allow all access to authenticated users"
  ON donors
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Log the changes
DO $$
DECLARE
  policy_count integer;
BEGIN
  SELECT COUNT(*) INTO policy_count
  FROM pg_policies
  WHERE schemaname = 'public' AND tablename = 'donors';
  
  RAISE NOTICE 'Updated RLS policies for donors table. Total policies: %', policy_count;
END $$;