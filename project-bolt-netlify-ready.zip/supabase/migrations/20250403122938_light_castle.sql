/*
  # Assign admin role to specific user
  
  1. Changes
    - Assign admin role to phillip.simon@gmail.com
    - Ensure idempotency by checking if role is already assigned
*/

-- Assign admin role to specific user
INSERT INTO user_roles (user_id, role_id)
SELECT 
  users.id,
  roles.id
FROM auth.users as users
CROSS JOIN roles
WHERE 
  roles.name = 'admin'
  AND users.email = 'phillip.simon@gmail.com'
  AND NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_roles.user_id = users.id
    AND user_roles.role_id = roles.id
  );