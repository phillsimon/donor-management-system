/*
  # Remove NOT NULL constraint from user_id column
  
  1. Changes
    - Remove NOT NULL constraint from user_id column in donors table
    - Allow donors to be created without a user_id
  
  2. Security
    - Maintains existing RLS settings
    - Allows public access to donor data
*/

-- Remove NOT NULL constraint from user_id column
ALTER TABLE donors
ALTER COLUMN user_id DROP NOT NULL;