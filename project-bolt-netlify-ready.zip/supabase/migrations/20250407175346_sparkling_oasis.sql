/*
  # Update donors table schema to match CSV headers exactly
  
  1. Changes
    - Rename all columns to match CSV headers exactly
    - Add proper indexes for performance
  
  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  -- First, rename any columns that don't match CSV headers
  ALTER TABLE donors 
    RENAME COLUMN "first_name" TO "First Name";
  
  ALTER TABLE donors 
    RENAME COLUMN "middle_name" TO "Middle Name";
  
  ALTER TABLE donors 
    RENAME COLUMN "last_name" TO "Last Name";
  
  ALTER TABLE donors 
    RENAME COLUMN "address" TO "Address";
  
  ALTER TABLE donors 
    RENAME COLUMN "address_2" TO "Address 2";
  
  ALTER TABLE donors 
    RENAME COLUMN "city" TO "City";
  
  ALTER TABLE donors 
    RENAME COLUMN "state" TO "State";
  
  ALTER TABLE donors 
    RENAME COLUMN "zip" TO "Zip";
  
  ALTER TABLE donors 
    RENAME COLUMN "phone_number" TO "Phone Number";
  
  ALTER TABLE donors 
    RENAME COLUMN "client_id" TO "Client ID";

  -- Update indexes to use new column names
  DROP INDEX IF EXISTS donors_client_id_idx;
  CREATE INDEX donors_client_id_idx ON donors("Client ID");
END $$;