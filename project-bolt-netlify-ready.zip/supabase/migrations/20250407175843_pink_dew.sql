/*
  # Update all donors table columns to match CSV headers exactly
  
  1. Changes
    - Rename all columns to match CSV headers exactly
    - Add column existence checks to prevent errors
    - Update indexes to use correct column names
  
  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  -- Rename columns only if they exist
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'ds_rating') THEN
    ALTER TABLE donors RENAME COLUMN "ds_rating" TO "DS Rating";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'quality_score') THEN
    ALTER TABLE donors RENAME COLUMN "quality_score" TO "Quality Score";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'profile') THEN
    ALTER TABLE donors RENAME COLUMN "profile" TO "Profile";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'rfm_total') THEN
    ALTER TABLE donors RENAME COLUMN "rfm_total" TO "RFM Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'last_gift_date') THEN
    ALTER TABLE donors RENAME COLUMN "last_gift_date" TO "Last Gift Date";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'total_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "total_gift_amount" TO "Total Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'age') THEN
    ALTER TABLE donors RENAME COLUMN "age" TO "Age";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'date_of_birth') THEN
    ALTER TABLE donors RENAME COLUMN "date_of_birth" TO "Date Of Birth";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'notes') THEN
    ALTER TABLE donors RENAME COLUMN "notes" TO "Notes";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'largest_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "largest_gift_amount" TO "Largest Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'largest_gift_date') THEN
    ALTER TABLE donors RENAME COLUMN "largest_gift_date" TO "Largest Gift Date";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'last_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "last_gift_amount" TO "Last Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'first_date_range') THEN
    ALTER TABLE donors RENAME COLUMN "first_date_range" TO "First Date Range";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'first_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "first_gift_amount" TO "First Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'total_of_likely_matches') THEN
    ALTER TABLE donors RENAME COLUMN "total_of_likely_matches" TO "Total Of Likely Matches";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'foundation') THEN
    ALTER TABLE donors RENAME COLUMN "foundation" TO "Foundation";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'fnd_assets') THEN
    ALTER TABLE donors RENAME COLUMN "fnd_assets" TO "Fnd Assets";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'non_profit') THEN
    ALTER TABLE donors RENAME COLUMN "non_profit" TO "NonProfit";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'political_likely_count') THEN
    ALTER TABLE donors RENAME COLUMN "political_likely_count" TO "Political Likely Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'political_likely_total') THEN
    ALTER TABLE donors RENAME COLUMN "political_likely_total" TO "Political Likely Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'maybe_total') THEN
    ALTER TABLE donors RENAME COLUMN "maybe_total" TO "Maybe Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'largest_gift_found') THEN
    ALTER TABLE donors RENAME COLUMN "largest_gift_found" TO "Largest Gift Found";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'largest_gift_found_lower_range') THEN
    ALTER TABLE donors RENAME COLUMN "largest_gift_found_lower_range" TO "Largest Gift Found Lower Range";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'wealth_based_capacity') THEN
    ALTER TABLE donors RENAME COLUMN "wealth_based_capacity" TO "Wealth-Based Capacity";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'real_estate_est') THEN
    ALTER TABLE donors RENAME COLUMN "real_estate_est" TO "Real Estate Est";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'real_estate_trust') THEN
    ALTER TABLE donors RENAME COLUMN "real_estate_trust" TO "Real Estate Trust";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'zestimate_total') THEN
    ALTER TABLE donors RENAME COLUMN "zestimate_total" TO "Zestimate Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'zestimate_count') THEN
    ALTER TABLE donors RENAME COLUMN "zestimate_count" TO "Zestimate Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'ln_total') THEN
    ALTER TABLE donors RENAME COLUMN "ln_total" TO "LN Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'ln_count') THEN
    ALTER TABLE donors RENAME COLUMN "ln_count" TO "LN Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'sec_stock_value') THEN
    ALTER TABLE donors RENAME COLUMN "sec_stock_value" TO "SEC Stock Value";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'sec_stock_or_insider') THEN
    ALTER TABLE donors RENAME COLUMN "sec_stock_or_insider" TO "SEC Stock or Insider";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'market_guide') THEN
    ALTER TABLE donors RENAME COLUMN "market_guide" TO "Market Guide";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'market_guide_comp') THEN
    ALTER TABLE donors RENAME COLUMN "market_guide_comp" TO "Market Guide Comp";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'market_guide_options') THEN
    ALTER TABLE donors RENAME COLUMN "market_guide_options" TO "Market Guide Options";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'business_revenue') THEN
    ALTER TABLE donors RENAME COLUMN "business_revenue" TO "Business Revenue";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'business_affiliation') THEN
    ALTER TABLE donors RENAME COLUMN "business_affiliation" TO "Business Affiliation";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'pension_admin') THEN
    ALTER TABLE donors RENAME COLUMN "pension_admin" TO "Pension Admin";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'pension_assets') THEN
    ALTER TABLE donors RENAME COLUMN "pension_assets" TO "Pension Assets";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'estimated_capacity') THEN
    ALTER TABLE donors RENAME COLUMN "estimated_capacity" TO "Estimated Capacity";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'annual_fund_likelihood') THEN
    ALTER TABLE donors RENAME COLUMN "annual_fund_likelihood" TO "Annual Fund Likelihood";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'major_gift_likelihood') THEN
    ALTER TABLE donors RENAME COLUMN "major_gift_likelihood" TO "Major Gift Likelihood";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'pgid') THEN
    ALTER TABLE donors RENAME COLUMN "pgid" TO "PGID";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'vip_match') THEN
    ALTER TABLE donors RENAME COLUMN "vip_match" TO "Vip Match";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'inner_circle') THEN
    ALTER TABLE donors RENAME COLUMN "inner_circle" TO "Inner Circle";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'average_home_value') THEN
    ALTER TABLE donors RENAME COLUMN "average_home_value" TO "Average Home Value";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'median_household_income') THEN
    ALTER TABLE donors RENAME COLUMN "median_household_income" TO "Median Household Income";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'corp_tech') THEN
    ALTER TABLE donors RENAME COLUMN "corp_tech" TO "Corp Tech";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'faa_pilots') THEN
    ALTER TABLE donors RENAME COLUMN "faa_pilots" TO "FAA Pilots";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'airplane_owner') THEN
    ALTER TABLE donors RENAME COLUMN "airplane_owner" TO "Airplane Owner";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'boat_owner') THEN
    ALTER TABLE donors RENAME COLUMN "boat_owner" TO "Boat Owner";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'whos_who') THEN
    ALTER TABLE donors RENAME COLUMN "whos_who" TO "Whos Who";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'rfm_recent_gift') THEN
    ALTER TABLE donors RENAME COLUMN "rfm_recent_gift" TO "RFM Recent Gift";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'rfm_freq') THEN
    ALTER TABLE donors RENAME COLUMN "rfm_freq" TO "RFM Freq";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'rfm_money') THEN
    ALTER TABLE donors RENAME COLUMN "rfm_money" TO "RFM Money";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'classic_quality_score') THEN
    ALTER TABLE donors RENAME COLUMN "classic_quality_score" TO "Classic Quality Score";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'prefix') THEN
    ALTER TABLE donors RENAME COLUMN "prefix" TO "Prefix";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'suffix') THEN
    ALTER TABLE donors RENAME COLUMN "suffix" TO "Suffix";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'higher_education_count') THEN
    ALTER TABLE donors RENAME COLUMN "higher_education_count" TO "Higher Education Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'higher_education_total') THEN
    ALTER TABLE donors RENAME COLUMN "higher_education_total" TO "Higher Education Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'education_gift_count') THEN
    ALTER TABLE donors RENAME COLUMN "education_gift_count" TO "Education Gift Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'education_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "education_gift_amount" TO "Education Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'philanthropy_and_grantmaking_count') THEN
    ALTER TABLE donors RENAME COLUMN "philanthropy_and_grantmaking_count" TO "Philanthropy and Grantmaking Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'philanthropy_and_grantmaking_total') THEN
    ALTER TABLE donors RENAME COLUMN "philanthropy_and_grantmaking_total" TO "Philanthropy and Grantmaking Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'healthcare_count') THEN
    ALTER TABLE donors RENAME COLUMN "healthcare_count" TO "Healthcare Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'healthcare_total') THEN
    ALTER TABLE donors RENAME COLUMN "healthcare_total" TO "Healthcare Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'arts_gift_count') THEN
    ALTER TABLE donors RENAME COLUMN "arts_gift_count" TO "Arts Gift Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'arts_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "arts_gift_amount" TO "Arts Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'republican_gift_count') THEN
    ALTER TABLE donors RENAME COLUMN "republican_gift_count" TO "Republican Gift Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'republican_gift_total') THEN
    ALTER TABLE donors RENAME COLUMN "republican_gift_total" TO "Republican Gift Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'democratic_gift_count') THEN
    ALTER TABLE donors RENAME COLUMN "democratic_gift_count" TO "Democratic Gift Count";
  END IF;

  -- Note: This column was causing the error, so we check if it exists with the correct name
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'democratic_gift_amount') THEN
    ALTER TABLE donors RENAME COLUMN "democratic_gift_amount" TO "Democratic Gift Amount";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'other_political_count') THEN
    ALTER TABLE donors RENAME COLUMN "other_political_count" TO "Other Political Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'other_political_total') THEN
    ALTER TABLE donors RENAME COLUMN "other_political_total" TO "Other Political Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'religion_count') THEN
    ALTER TABLE donors RENAME COLUMN "religion_count" TO "Religion Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'religion_total') THEN
    ALTER TABLE donors RENAME COLUMN "religion_total" TO "Religion Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'society_benefit_count') THEN
    ALTER TABLE donors RENAME COLUMN "society_benefit_count" TO "Society Benefit Count";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'society_benefit_total') THEN
    ALTER TABLE donors RENAME COLUMN "society_benefit_total" TO "Society Benefit Total";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'shale_wealth') THEN
    ALTER TABLE donors RENAME COLUMN "shale_wealth" TO "Shale Wealth";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'mbt_net_worth') THEN
    ALTER TABLE donors RENAME COLUMN "mbt_net_worth" TO "MBT Net Worth";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'mbt_income_estimate') THEN
    ALTER TABLE donors RENAME COLUMN "mbt_income_estimate" TO "MBT Income Estimate";
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'donors' AND column_name = 'mbt_highest_asset') THEN
    ALTER TABLE donors RENAME COLUMN "mbt_highest_asset" TO "MBT Highest Asset";
  END IF;

  -- Update indexes to use new column names
  DROP INDEX IF EXISTS donors_user_id_idx;
  DROP INDEX IF EXISTS donors_client_id_idx;
  DROP INDEX IF EXISTS donors_user_id_created_at_idx;
  
  CREATE INDEX donors_user_id_idx ON donors(user_id);
  CREATE INDEX donors_client_id_idx ON donors("Client ID");
  CREATE INDEX donors_user_id_created_at_idx ON donors(user_id, created_at DESC);
END $$;