/*
  # Fix gift matches column naming
  
  1. Changes
    - Ensure num_of_gift_matches column exists
    - Add proper indexes
  
  2. Security
    - Maintains existing RLS policies
*/

-- Ensure the column exists with proper name
DO $$ 
BEGIN
  -- First check if the old column exists and drop it if it does
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'donors' AND column_name = '# Of Gift Matches'
  ) THEN
    ALTER TABLE donors DROP COLUMN "# Of Gift Matches";
  END IF;

  -- Then ensure the proper column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'donors' AND column_name = 'num_of_gift_matches'
  ) THEN
    ALTER TABLE donors ADD COLUMN num_of_gift_matches INTEGER DEFAULT 0;
  END IF;
END $$;

-- Add index for performance
CREATE INDEX IF NOT EXISTS donors_num_gift_matches_idx ON donors(num_of_gift_matches);