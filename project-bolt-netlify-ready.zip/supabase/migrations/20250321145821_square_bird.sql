/*
  # Update workflow responses schema and policies

  1. Changes
    - Add indexes for better query performance
    - Update RLS policies for better access control
    - Add user profile view improvements

  2. Security
    - Maintain RLS enabled
    - Update policies for collaborative access
*/

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS workflow_responses_donor_id_idx ON workflow_responses(donor_id);
CREATE INDEX IF NOT EXISTS workflow_responses_user_id_idx ON workflow_responses(user_id);
CREATE INDEX IF NOT EXISTS workflow_responses_created_at_idx ON workflow_responses(created_at);

-- Drop existing user_profiles view if it exists
DROP VIEW IF EXISTS user_profiles;

-- Recreate user_profiles view with better structure
CREATE OR REPLACE VIEW user_profiles AS
SELECT 
  id,
  email,
  raw_user_meta_data->>'full_name' as full_name,
  created_at,
  last_sign_in_at
FROM auth.users;

-- Ensure proper access to the view
GRANT SELECT ON user_profiles TO authenticated;

-- Update RLS policies
ALTER TABLE workflow_responses DISABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_responses ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Users can insert their own responses" ON workflow_responses;
DROP POLICY IF EXISTS "Users can read all responses" ON workflow_responses;
DROP POLICY IF EXISTS "Users can update their own responses" ON workflow_responses;

-- Create new policies
CREATE POLICY "Users can insert their own responses"
  ON workflow_responses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read all responses"
  ON workflow_responses
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update their own responses"
  ON workflow_responses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);