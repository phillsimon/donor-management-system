import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Users, 
  Heart, 
  Calendar, 
  ChevronRight, 
  ChevronLeft,
  Building2,
  Target,
  Brain,
  CheckCircle,
  Save,
  AlertCircle,
  Loader2
} from 'lucide-react';
import type { Donor } from '../../types';
import { SavedAnalyses } from './SavedAnalyses';
import { useWorkflowResponses } from '../../hooks/useWorkflowResponses';

interface DonorAnalysisProps {
  donor: Donor;
  onClose: () => void;
}

interface AnalysisStep {
  id: string;
  title: string;
  description: string;
  questions: Question[];
}

interface Question {
  id: string;
  text: string;
  type: 'text' | 'radio' | 'checkbox' | 'number';
  options?: string[];
  required?: boolean;
}

interface Answer {
  questionId: string;
  value: string | string[];
}

export function DonorAnalysis({ donor, onClose }: DonorAnalysisProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, Answer>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [showSaved, setShowSaved] = useState(false);
  
  const donorId = donor['Client ID'] || `${donor['First Name']}_${donor['Last Name']}`;
  const { responses, loading, error, saveResponse, parseResponse } = useWorkflowResponses(donorId);

  useEffect(() => {
    if (responses.length > 0) {
      const savedAnswers: Record<string, Answer> = {};
      responses.forEach(response => {
        savedAnswers[response.question_id] = {
          questionId: response.question_id,
          value: parseResponse(response.response)
        };
      });
      setAnswers(savedAnswers);
    }
  }, [responses]);

  const steps: AnalysisStep[] = [
    {
      id: 'wealth-indicators',
      title: 'Wealth Indicators',
      description: 'Analyze the donor\'s financial capacity and wealth sources',
      questions: [
        {
          id: 'occupation-wealth',
          text: 'What do we know about this donor\'s occupation or primary source of wealth?',
          type: 'text',
          required: true
        },
        {
          id: 'prior-commitments',
          text: 'Has the donor previously made substantial philanthropic commitments ($50,000 or more) elsewhere?',
          type: 'radio',
          options: ['Yes', 'No', 'Unknown'],
          required: true
        },
        {
          id: 'wealth-screening',
          text: 'Have we obtained wealth-screening data confirming the prospect\'s giving capacity?',
          type: 'checkbox',
          options: [
            'Real estate holdings verified',
            'Business revenue confirmed',
            'Stock holdings identified',
            'Foundation assets verified',
            'Other assets identified'
          ]
        }
      ]
    },
    {
      id: 'affinity-interest',
      title: 'Affinity and Interest',
      description: 'Evaluate connections and relationships to our organization',
      questions: [
        {
          id: 'org-connections',
          text: 'What specific connections does the donor have to our organization?',
          type: 'checkbox',
          options: [
            'Board member relationships',
            'Staff connections',
            'Volunteer history',
            'Event attendance',
            'Program participation'
          ]
        },
        {
          id: 'stakeholder-relationships',
          text: 'Are there key stakeholder relationships we can leverage?',
          type: 'text'
        },
        {
          id: 'project-interest',
          text: 'Has the donor expressed enthusiasm for our initiatives?',
          type: 'radio',
          options: [
            'Strong interest shown',
            'Moderate interest',
            'No clear interest',
            'Need more information'
          ],
          required: true
        }
      ]
    },
    {
      id: 'gift-history',
      title: 'Gift History and Behavior',
      description: 'Review past giving patterns and current potential',
      questions: [
        {
          id: 'giving-history',
          text: 'What\'s their previous giving history with our organization?',
          type: 'text',
          required: true
        },
        {
          id: 'liquidity-events',
          text: 'Are there any recent events indicating increased giving capacity?',
          type: 'checkbox',
          options: [
            'Business sale/merger',
            'Inheritance',
            'Stock options exercised',
            'Real estate transaction',
            'Other liquidity event'
          ]
        },
        {
          id: 'giving-potential',
          text: 'What is the estimated giving potential for this donor?',
          type: 'number',
          required: true
        }
      ]
    },
    {
      id: 'cultivation-timing',
      title: 'Cultivation and Timing',
      description: 'Plan the approach and engagement strategy',
      questions: [
        {
          id: 'cultivation-stage',
          text: 'Where are we in the cultivation cycle?',
          type: 'radio',
          options: [
            'Initial identification',
            'Qualification',
            'Cultivation',
            'Ready for solicitation',
            'Stewardship'
          ],
          required: true
        },
        {
          id: 'timing-signals',
          text: 'What signals has the donor provided regarding timing?',
          type: 'text'
        },
        {
          id: 'motivation-factors',
          text: 'What recognition opportunities would motivate this donor?',
          type: 'checkbox',
          options: [
            'Naming opportunities',
            'Leadership recognition',
            'Program involvement',
            'Public acknowledgment',
            'Private recognition'
          ]
        }
      ]
    },
    {
      id: 'decision-making',
      title: 'Decision-Making Process',
      description: 'Understand how the donor makes giving decisions',
      questions: [
        {
          id: 'decision-process',
          text: 'How does the donor typically make philanthropic decisions?',
          type: 'radio',
          options: [
            'Independent decision-maker',
            'Consults with spouse/partner',
            'Family foundation process',
            'Professional advisor involved',
            'Unknown'
          ],
          required: true
        },
        {
          id: 'decision-timeline',
          text: 'What is their typical timeline for making major gift decisions?',
          type: 'radio',
          options: [
            'Quick (within 1 month)',
            'Moderate (1-3 months)',
            'Extended (3-6 months)',
            'Very long (6+ months)',
            'Unknown'
          ]
        }
      ]
    }
  ];

  const currentStep = steps[currentStepIndex];

  const handleAnswer = async (questionId: string, value: string | string[]) => {
    try {
      await saveResponse(steps[currentStepIndex].id, questionId, value);
      
      setAnswers(prev => ({
        ...prev,
        [questionId]: { questionId, value }
      }));
    } catch (err) {
      console.error('Failed to save response:', err);
    }
  };

  const canProceed = () => {
    const requiredQuestions = currentStep.questions.filter(q => q.required);
    return requiredQuestions.every(q => answers[q.id]?.value);
  };

  const handleLoadAnalysis = (stepId: string) => {
    const stepIndex = steps.findIndex(step => step.id === stepId);
    if (stepIndex >= 0) {
      setCurrentStepIndex(stepIndex);
      setShowSaved(false);
    }
  };

  const handleSaveForLater = async () => {
    try {
      const currentStep = steps[currentStepIndex];
      const answeredQuestions = currentStep.questions.filter(q => answers[q.id]);
      
      for (const question of answeredQuestions) {
        await saveResponse(
          currentStep.id,
          question.id,
          answers[question.id].value
        );
      }

      setShowSaved(true);
    } catch (err) {
      console.error('Failed to save analysis:', err);
    }
  };

  const renderQuestion = (question: Question) => {
    const currentAnswer = answers[question.id]?.value || '';

    switch (question.type) {
      case 'checkbox':
        return (
          <div className="space-y-2">
            {question.options?.map(option => (
              <label key={option} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={Array.isArray(currentAnswer) && currentAnswer.includes(option)}
                  onChange={(e) => {
                    const newValue = Array.isArray(currentAnswer) ? currentAnswer : [];
                    if (e.target.checked) {
                      handleAnswer(question.id, [...newValue, option]);
                    } else {
                      handleAnswer(question.id, newValue.filter(v => v !== option));
                    }
                  }}
                  className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                />
                <span>{option}</span>
              </label>
            ))}
          </div>
        );

      case 'radio':
        return (
          <div className="space-y-2">
            {question.options?.map(option => (
              <label key={option} className="flex items-center space-x-2">
                <input
                  type="radio"
                  name={question.id}
                  value={option}
                  checked={currentAnswer === option}
                  onChange={(e) => handleAnswer(question.id, e.target.value)}
                  className="border-gray-300 text-purple-600 focus:ring-purple-500"
                />
                <span>{option}</span>
              </label>
            ))}
          </div>
        );

      case 'number':
        return (
          <input
            type="number"
            value={currentAnswer as string}
            onChange={(e) => handleAnswer(question.id, e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
            placeholder="Enter amount..."
          />
        );

      default:
        return (
          <textarea
            value={currentAnswer as string}
            onChange={(e) => handleAnswer(question.id, e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
            rows={3}
            placeholder="Enter your analysis..."
          />
        );
    }
  };

  const renderAnalysisDashboard = () => {
    const getIcon = (score: number) => {
      if (score >= 80) return 'text-green-500';
      if (score >= 60) return 'text-yellow-500';
      return 'text-red-500';
    };

    const metrics = [
      {
        label: 'Wealth Capacity',
        value: donor['Estimated Capacity'],
        icon: <DollarSign className={`h-5 w-5 ${getIcon(90)}`} />
      },
      {
        label: 'Affinity Score',
        value: `${donor['Annual Fund Likelihood']}%`,
        icon: <Heart className={`h-5 w-5 ${getIcon(donor['Annual Fund Likelihood'])}`} />
      },
      {
        label: 'Major Gift Potential',
        value: `${donor['Major Gift Likelihood']}%`,
        icon: <Target className={`h-5 w-5 ${getIcon(donor['Major Gift Likelihood'])}`} />
      },
      {
        label: 'Business Revenue',
        value: donor['Business Revenue'],
        icon: <Building2 className={`h-5 w-5 ${getIcon(75)}`} />
      }
    ];

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white p-4 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">{metric.label}</span>
                {metric.icon}
              </div>
              <div className="mt-2 text-xl font-semibold">{metric.value}</div>
            </div>
          ))}
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Analysis Summary</h3>
          <div className="space-y-4">
            {steps.map((step, index) => (
              <div key={step.id} className="border-l-4 border-purple-500 pl-4">
                <h4 className="text-md font-medium text-gray-700">{step.title}</h4>
                <div className="mt-2 text-sm text-gray-600">
                  {Object.entries(answers)
                    .filter(([key]) => step.questions.some(q => q.id === key))
                    .map(([key, answer]) => {
                      const question = step.questions.find(q => q.id === key);
                      return (
                        <div key={key} className="mt-2">
                          <span className="font-medium">{question?.text}</span>
                          <p className="mt-1">
                            {Array.isArray(answer.value) 
                              ? answer.value.join(', ') 
                              : answer.value}
                          </p>
                        </div>
                      );
                    })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  if (showSaved) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-600" />
            <h2 className="text-2xl font-bold text-gray-800">Saved Analyses</h2>
          </div>
          <button
            onClick={() => setShowSaved(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            ×
          </button>
        </div>

        <SavedAnalyses donor={donor} onLoadAnalysis={handleLoadAnalysis} />
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg">
      <div className="h-2 bg-gray-200 rounded-t-lg">
        <div
          className="h-full bg-purple-600 rounded-tl-lg transition-all duration-300"
          style={{ width: `${((currentStepIndex + 1) / steps.length) * 100}%` }}
        />
      </div>

      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-600" />
            <h2 className="text-2xl font-bold text-gray-800">Donor Analysis</h2>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowSaved(true)}
              className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Saved Analyses
            </button>
            <button
              onClick={handleSaveForLater}
              className="flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200"
            >
              <Save className="w-4 h-4" />
              Save for Later
            </button>
          </div>
        </div>

        {currentStepIndex === steps.length ? (
          renderAnalysisDashboard()
        ) : (
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">{currentStep.title}</h3>
              <p className="mt-1 text-gray-600">{currentStep.description}</p>
            </div>

            <div className="space-y-6">
              {currentStep.questions.map(question => (
                <div key={question.id} className="space-y-2">
                  <label className="block font-medium text-gray-700">
                    {question.text}
                    {question.required && <span className="text-red-500 ml-1">*</span>}
                  </label>
                  {renderQuestion(question)}
                </div>
              ))}
            </div>

            <div className="flex justify-between pt-4">
              <button
                onClick={() => setCurrentStepIndex(prev => Math.max(0, prev - 1))}
                disabled={currentStepIndex === 0}
                className="flex items-center gap-1 px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50"
              >
                <ChevronLeft className="w-4 h-4" />
                Previous
              </button>
              <button
                onClick={() => setCurrentStepIndex(prev => 
                  prev === steps.length - 1 ? steps.length : Math.min(steps.length - 1, prev + 1)
                )}
                disabled={!canProceed()}
                className="flex items-center gap-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
              >
                {currentStepIndex === steps.length - 1 ? (
                  <>
                    Complete Analysis
                    <CheckCircle className="w-4 h-4 ml-1" />
                  </>
                ) : (
                  <>
                    Next
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="absolute inset-0 bg-white bg-opacity-50 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border-l-4 border-red-500">
          <div className="flex items-center gap-2 text-red-700">
            <AlertCircle className="w-5 h-5" />
            <p>{error}</p>
          </div>
        </div>
      )}
    </div>
  );
}