import React, { useState } from 'react';
import { User, FileText, ChevronRight, PenSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { Donor } from '../../types';
import { DonorAnalysis } from './DonorAnalysis';
import { DonorDashboard } from './DonorDashboard';
import { NoteModal } from './NoteModal';

interface DonorDetailsProps {
  donor: Donor;
  onClose: () => void;
  onResetDonor: () => void;
}

export function DonorDetails({ donor, onClose, onResetDonor }: DonorDetailsProps) {
  const [view, setView] = useState<'details' | 'analysis' | 'dashboard'>('dashboard');
  const [showNoteModal, setShowNoteModal] = useState(false);
  const navigate = useNavigate();

  const donorId = donor.id;

  switch (view) {
    case 'analysis':
      return <DonorAnalysis donor={donor} onClose={() => setView('dashboard')} />;
    case 'dashboard':
      return (
        <div className="relative">
          <DonorDashboard donor={donor} onClose={onClose} onResetDonor={onResetDonor} />
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              onClick={() => setShowNoteModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <PenSquare className="w-4 h-4" />
              Add Note
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigate(`/donors/${donor.id}/notes`)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <PenSquare className="w-4 h-4" />
              Show Notes
              <ChevronRight className="w-4 h-4" />
            </button>
            
            <button
              onClick={() => setView('analysis')}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <FileText className="w-4 h-4" />
              Start Analysis
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          {showNoteModal && (
            <NoteModal
              isOpen={showNoteModal}
              onClose={() => setShowNoteModal(false)}
              donorId={donorId}
            />
          )}
        </div>
      );
    default:
      return (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-2">
              <User className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-800">
                {donor['First Name']} {donor['Middle Name']} {donor['Last Name']}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setView('analysis')}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <FileText className="w-4 h-4" />
                Start Analysis
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowNoteModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <PenSquare className="w-4 h-4" />
                Add Note
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(donor).map(([key, value]) => (
              <div key={key} className="p-3 bg-gray-50 rounded-lg">
                <div className="text-sm font-medium text-gray-500">{key}</div>
                <div className="mt-1 text-base text-gray-900">{value || 'N/A'}</div>
              </div>
            ))}
          </div>
          {showNoteModal && (
            <NoteModal
              isOpen={showNoteModal}
              onClose={() => setShowNoteModal(false)}
              donorId={donorId}
            />
          )}
        </div>
      );
  }
}