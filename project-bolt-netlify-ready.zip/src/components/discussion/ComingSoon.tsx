import React from 'react';

export function ComingSoon() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Coming Soon</h2>
      <p className="text-gray-600">
        The discussion feature is currently under development. Check back soon for updates!
      </p>
    </div>
  );
}